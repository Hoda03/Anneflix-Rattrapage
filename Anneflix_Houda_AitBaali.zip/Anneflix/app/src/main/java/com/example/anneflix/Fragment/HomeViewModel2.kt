package com.example.anneflix.Fragment

import androidx.lifecycle.ViewModel

class HomeViewModel2 : ViewModel() {
    // TODO: Implement the ViewModel
}